###########
  kacheado @tonywarlley:
###########

	SKIN MOD by TONYWARLLEY para Kodi 16 Android, Kodi 16 e Kodi 17.
	https://www.youtube.com/TonyWarlley 
	Proibida a Copia ou Venda. 
	Se gostou nao esqueca de se Inscrever e Deixar o LIKE ! 

	Se quiser ajudar e contribuir com qlq quantia:

******************************************************************* 
	CAIXA ECONOMICA FEDERAL 

	TONY W P BORDINI 
	Ag: 2485 
	Operacao: 013 
	Conta 9.461-2 

	Ou entre em contato : tony_wpb@hotmail.com 
	
	Obrigado ! 

*************************************************************** 

CHUPA CUZ�O...KKKKKK

        