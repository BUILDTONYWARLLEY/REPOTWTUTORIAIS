# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/user/Brasileiros
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools

from addon.common.addon import Addon

addonID = 'plugin.video.DiariodeMotochileiroAfredoSouza'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')
base    = 'plugin://plugin.video.youtube/'

icon1 = 'special://home/addons/plugin.video.DiariodeMotochileiroAfredoSouza/capas/icon1.png'
icon2 = 'special://home/addons/plugin.video.DiariodeMotochileiroAfredoSouza/capas/icon2.png'
icon3 = 'special://home/addons/plugin.video.DiariodeMotochileiroAfredoSouza/capas/icon3.png'
icon4 = 'special://home/addons/plugin.video.DiariodeMotochileiroAfredoSouza/capas/icon4.png'
icon5 = 'special://home/addons/plugin.video.DiariodeMotochileiroAfredoSouza/capas/icon5.png'
icon6 = 'special://home/addons/plugin.video.DiariodeMotochileiroAfredoSouza/capas/icon6.png'
icon7 = 'special://home/addons/plugin.video.DiariodeMotochileiroAfredoSouza/capas/icon7.png'
icon8 = 'special://home/addons/plugin.video.DiariodeMotochileiroAfredoSouza/capas/icon8.png'
icon9 = 'special://home/addons/plugin.video.DiariodeMotochileiroAfredoSouza/capas/icon9.png'
icon10 = 'special://home/addons/plugin.video.DiariodeMotochileiroAfredoSouza/capas/icon10.png'


def run():
    plugintools.log("DiariodeMotochileiroAfredoSouza.run")
    
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def main_list(params):
		plugintools.log("DiariodeMotochileiroAfredoSouza ===> " + repr(params))

		plugintools.add_item(title = "[B][COLOR gold]Diário de Motochileiro por Alfredo Souza[/COLOR][/B]" , url = base + "channel/UCq6QFCtxkE87Bo5DOz22Fzw/", thumbnail = icon1, folder = True)
		plugintools.add_item(title = "[B][COLOR gold]Preparação para volta ao mundo [/COLOR][/B]" , url = base + "playlist/PL_X_K1L0CMS4wJrIJHNVl0A5zNRCqMmDK/", thumbnail = icon2, folder = True)
		plugintools.add_item(title = "[B][COLOR gold]Primeira Temporada - Altiplanos e Patagônia[/COLOR][/B]" , url = base + "playlist/PL_X_K1L0CMS4wJrIJHNVl0A5zNRCqMmDK/", thumbnail = icon3, folder = True)
		plugintools.add_item(title = "[B][COLOR gold]Segunda Temporada - Brasil [/COLOR][/B]" , url = base + "playlist/PL_X_K1L0CMS7Ajy1nxIT-Y4ltTWnDcy2w/", thumbnail = icon4, folder = True)
		plugintools.add_item(title = "[B][COLOR gold]Terceira Temporada - Peru a México[/COLOR][/B]" , url = base + "playlist/PL_X_K1L0CMS7daL2zIQ3w01IRRyqBHDnX/", thumbnail = icon5, folder = True)
		plugintools.add_item(title = "[B][COLOR gold]Quarta Temporada - EUA e Canadá[/COLOR][/B]" , url = base + "playlist/PL_X_K1L0CMS52El8JrqV-CU3VlMPnJrUO/", thumbnail = icon6, folder = True)
		plugintools.add_item(title = "[B][COLOR gold]Quinta Temporada - México [/COLOR][/B]" , url = base + "playlist/PL_X_K1L0CMS7-0KhToRFlD7ydMg9N1T2W/", thumbnail = icon7, folder = True)
		plugintools.add_item(title = "[B][COLOR gold]Sexta Temporada - Agora Somos 2[/COLOR][/B]" , url = base + "playlist/PL_X_K1L0CMS4A5KCsPUIhdPpgvaxekEBd/", thumbnail = icon8, folder = True)
		plugintools.add_item(title = "[B][COLOR gold]Quarentena no Panamá[/COLOR][/B]" , url = base + "playlist/PL_X_K1L0CMS6PznvmkTKaRTaZaTcD5Eb9/", thumbnail = icon9, folder = True)
		plugintools.add_item(title = "[B][COLOR gold]Papo de Maluko[/COLOR][/B]" , url = base + "playlist/PL_X_K1L0CMS6pvKwg98KauiF0GX0e6sM0/", thumbnail = icon10, folder = True)


	
		
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmc.executebuiltin('Container.SetViewMode(500)')
		
run()