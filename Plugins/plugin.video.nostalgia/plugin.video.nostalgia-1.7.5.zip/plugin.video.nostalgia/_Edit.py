import xbmcaddon

MainBase = 'http://addon.repotwtutoriais.hostingerapp.com/nostal/basenost'
addon = xbmcaddon.Addon('plugin.video.nostalgia')