import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/BUILDTONYWARLLEY/TONYWARLLEY/master/basenost'
addon = xbmcaddon.Addon('plugin.video.nostalgia')