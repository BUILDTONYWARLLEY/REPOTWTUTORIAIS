from requests_html import HTMLSession

session = HTMLSession()

r = session.get('https://cos.tv/videos/play/1578488508571752493')

r.html.render()
