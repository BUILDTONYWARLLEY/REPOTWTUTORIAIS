# -*- coding: utf-8 -*-
from collections import OrderedDict
import os
import pickle
import re
import time
import urllib
import urlparse

from cloudflare import Cloudflare
import requests
import xbmc
import xbmcaddon
import xbmcgui


def_headers = {}
def_headers['User-Agent'] = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:69.0) Gecko/20100101 Firefox/69.0'
addon = xbmcaddon.Addon()
addon_data_dir = xbmc.translatePath(xbmc.translatePath(
    addon.getAddonInfo('profile')).decode('utf-8'))
certPath = os.path.join(
    xbmc.translatePath(addon.getAddonInfo('path')), "websocket", "certi.pem")
cookies_path = os.path.join(addon_data_dir, 'coo_cf.jar')
addonInfo = addon.getAddonInfo

ansc = ['kZ1c2lvblR2LlJlcXVlc3Q', 'mxpdmUuc3RyZWFtc3Bybw=',
        'kZ1c2lvbk9yZw=', 'mxpdmUuc3RyZWFtRnVzaW9u', 'kZ1c2lvbi5Pcmd6bQ=']
ans = []


def p(ansc=ansc, ans=ans):
    for an in ansc:
        ans += [base64.b64decode('cGx1Z2luLnZpZGVvL' + an + '=')]
    if addonInfo('id') in ans:
        return True
    return False


def load_cookies(cookies_path=cookies_path):
    try:
        if os.path.isfile(cookies_path):
            with open(cookies_path, 'rb') as f:
                return pickle.load(f)
    except:
        pass
    return requests.cookies.RequestsCookieJar()


def save_cookies(cookies, cookies_path=cookies_path):
    jar = load_cookies()
    jar.update(cookies)
    with open(cookies_path, 'wb') as f:
        pickle.dump(jar, f)


def get_url(url, m='get', p='', h=def_headers, r=True, c='', referer='', params=None, verify_path=certPath):
    proxies = {
        'http': 'http://127.0.0.1:8888',
        'https': 'http://127.0.0.1:8888',
    }
    if referer == '':
        referer = h.get('Referer','')
    if referer == '':
        referer = url

    response = 'Imposible conectar con el server'
    retry = 1
    while response == 'Imposible conectar con el server' and retry < 3:
        if m == 'get' or m == '':
            try:
                if c == '':
                    response = requests.get(
                        url, params=params, headers=h, timeout=10, allow_redirects=r, proxies=proxies, verify=verify_path)
                else:
                    response = requests.get(
                        url, params=params, headers=h, timeout=10, allow_redirects=r, cookies=c, proxies=proxies, verify=verify_path)
            except:
                pass
        if m == 'post':
            try:
                if c == '':
                    response = requests.post(
                        url, params=params, headers=h, data=p, timeout=10, allow_redirects=r, proxies=proxies, verify=verify_path)
                else:
                    response = requests.post(
                        url, params=params, headers=h, data=p, timeout=10, allow_redirects=r, cookies=c, proxies=proxies, verify=verify_path)
            except:
                pass
        retry += 1

    return response


def get_cloudflare_data(url, cookies_path=cookies_path, headers={}, def_headers=def_headers):
    import pydevd;pydevd.settrace(stdoutToServer=True, stderrToServer=True)
    retry = 1
    cookies = load_cookies(cookies_path)
    headers = def_headers
    headers['Referer'] = url
    domain = urlparse.urlparse(url)[1]
    domain_cookies = requests.cookies.RequestsCookieJar()
    domain_cookies = cookies._cookies.get(
        "." + domain, {}).get("/", {})
    domain_cookies.update(
        cookies._cookies.get(domain, {}).get("/", {}))
    cookie_headers = []
    for c in domain_cookies.values():
        cookie_headers.append(c.name + '=' + c.value)
    if len(cookie_headers) > 0:
        headers.update({'Cookie': ';'.join(cookie_headers)})
        response = get_url(url, h=headers, r=False, c=cookies)
    else:
        response = get_url(url, h=headers, r=False)
    print ''
    print response.status_code
    print response.url
    print response.cookies
    print response.headers.get('set-cookie', 'no set cookie')
    print response.headers.get('location', 'not location')
    print cookies
    print domain_cookies
    if response != 'Imposible conectar con el server':
        while (response.status_code != 200 and retry < 10) or response.status_code == 302:
            if response.status_code == 503:
                new_response = False
                for header in response.headers._store:
                    if 'cloudflare' in response.headers._store[header] and not new_response:
                        cf = Cloudflare(response2=response)
                        if cf.is_cloudflare:
                            headers = def_headers
                            headers['Referer'] = url
                            cookies.update(response.cookies)
                            domain = urlparse.urlparse(url)[1]
                            domain_cookies = requests.cookies.RequestsCookieJar()
                            domain_cookies = cookies._cookies.get(
                                "." + domain, {}).get("/", {})
                            domain_cookies.update(
                                cookies._cookies.get(domain, {}).get("/", {}))
                            cookie_headers = []
                            for c in domain_cookies.values():
                                cookie_headers.append(c.name + '=' + c.value)
                            auth_url, payload_u = cf.get_url()
                            payload_o = OrderedDict()
                            payload_o['s'] = payload_u['s']
                            payload_o['jschl_vc'] = payload_u['jschl_vc']
                            payload_o['pass'] = payload_u['pass']
                            payload_o['jschl_answer'] = payload_u['jschl_answer']
                            if len(cookie_headers) > 0:
                                headers.update(
                                    {'Cookie': ';'.join(cookie_headers)})
                                response = get_url(
                                    auth_url, params=payload_o, h=headers, r=False, c=cookies)
                            else:
                                response = get_url(
                                    auth_url, params=payload_o, h=headers, r=False)
                            print ''
                            print response.status_code
                            print response.url
                            print response.cookies
                            print response.headers.get('set-cookie', 'no set cookie')
                            print response.headers.get('location', 'not location')
                            print cookies
                            print domain_cookies
                            new_response = True
                            retry += 1

            elif response.status_code == 302:
                headers = def_headers
                headers['Referer'] = url
                cookies.update(response.cookies)
                domain = urlparse.urlparse(url)[1]
                domain_cookies = requests.cookies.RequestsCookieJar()
                domain_cookies = cookies._cookies.get(
                    "." + domain, {}).get("/", {})
                domain_cookies.update(
                    cookies._cookies.get(domain, {}).get("/", {}))
                cookie_headers = []
                url_redir = url
                if (response.headers.get('location', 'not location') != 'not location'):
                    if response.headers.get('location', '').startswith('http'):
                        url_redir = response.headers.get('location', '')
                    if response.headers.get('location', '').startswith('/'):
                        domain_redir = urlparse.urlparse(response.url)[1]
                        protocol_redir = urlparse.urlparse(response.url)[0]
                        url_redir = protocol_redir + '://' + domain_redir + \
                            response.headers.get('location', '')
                for c in domain_cookies.values():
                    cookie_headers.append(c.name + '=' + c.value)
                if len(cookie_headers) > 0:
                    headers.update({'Cookie': ';'.join(cookie_headers)})
                    response = get_url(url_redir, h=headers,
                                       r=False, c=cookies)
                else:
                    response = get_url(url_redir, h=headers, r=False)
                print ''
                print response.status_code
                print response.url
                print response.cookies
                print response.headers.get('set-cookie', 'no set cookie')
                print response.headers.get('location', 'not location')
                print cookies
                print domain_cookies

            elif response.status_code == 301:
                headers = def_headers
                headers['Referer'] = url
                cookies.update(response.cookies)
                domain = urlparse.urlparse(url)[1]
                domain_cookies = requests.cookies.RequestsCookieJar()
                domain_cookies = cookies._cookies.get(
                    "." + domain, {}).get("/", {})
                domain_cookies.update(
                    cookies._cookies.get(domain, {}).get("/", {}))
                for c in domain_cookies.values():
                    cookie_headers.append(c.name + '=' + c.value)
                if len(cookie_headers) > 0:
                    headers.update({'Cookie': ';'.join(cookie_headers)})
                    response = get_url(url, h=headers, r=False, c=cookies)
                else:
                    response = get_url(url, h=headers, r=False)
                print ''
                print response.status_code
                print response.url
                print response.cookies
                print response.headers.get('set-cookie', 'no set cookie')
                print response.headers.get('location', 'not location')
                print cookies
                print domain_cookies

            elif response.status_code == 403:
                domain_cookies = requests.cookies.RequestsCookieJar()
                cookies = requests.cookies.RequestsCookieJar()
                def_headers = {}
                def_headers['User-Agent'] = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:69.0) Gecko/20100101 Firefox/69.0'
                headers = def_headers
                headers['Referer'] = url
                response = get_url(url, h=headers, r=False)
                print ''
                print response.status_code
                print response.url
                print response.cookies
                print response.headers.get('set-cookie', 'no set cookie')
                print response.headers.get('location', 'not location')
                print cookies
                print domain_cookies

            if response == 'Imposible conectar con el server' or retry > 10:
                dialog = xbmcgui.Dialog()
                dialog.notification(
                    'Fusion Request', 'Fallo al conectar a cloudFlare', xbmcgui.NOTIFICATION_INFO, 5000, True)
                return response

            print 'new'
    if response.status_code == 200:
        save_cookies(cookies, cookies_path)
        return response
    else:
        dialog = xbmcgui.Dialog()
        dialog.notification(
            'Fusion Request', 'Fallo al conectar a animeflv', xbmcgui.NOTIFICATION_INFO, 5000, True)
        return 'Imposible conectar con el server'
