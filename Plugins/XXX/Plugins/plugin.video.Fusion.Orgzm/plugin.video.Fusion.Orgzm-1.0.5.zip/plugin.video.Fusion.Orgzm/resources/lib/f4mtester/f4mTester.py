# -*- coding: utf-8 -*-
import sys

import xbmcplugin


def playF4mLink(url, name, proxy=None, use_proxy_for_chunks=False, maxbitrate=0, simpleDownloader=False, auth_string=None, streamtype='HDS', setResolved=False, swf="", callbackpath="", callbackparam="", iconImage="", replace_to=None, replace_from=None):
    from resources.lib.F4mProxy.F4mProxy import f4mProxyHelper
    player = f4mProxyHelper()
    #progress = xbmcgui.DialogProgress()
    #progress.create('Starting local proxy')

    if setResolved:
        urltoplay, item = player.playF4mLink(url, name, proxy, use_proxy_for_chunks, maxbitrate, simpleDownloader,
                                             auth_string, streamtype, setResolved, swf, callbackpath, callbackparam, iconImage, replace_to, replace_from)
        item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

    else:
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        player.playF4mLink(url, name, proxy, use_proxy_for_chunks, maxbitrate, simpleDownloader,
                           auth_string, streamtype, setResolved, swf, callbackpath, callbackparam, iconImage, replace_to, replace_from)

    return
