# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/user/Brasileiros
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools

from addon.common.addon import Addon

addonID = 'plugin.video.viagenstwt'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')
base    = 'plugin://plugin.video.youtube/'

icon1 = 'special://home/addons/plugin.video.viagenstwt/capas/icon1.png'
icon2 = 'special://home/addons/plugin.video.viagenstwt/capas/icon2.png'
icon3 = 'special://home/addons/plugin.video.viagenstwt/capas/icon3.png'
icon4 = 'special://home/addons/plugin.video.viagenstwt/capas/icon4.png'
icon5 = 'special://home/addons/plugin.video.viagenstwt/capas/icon5.png'
icon6 = 'special://home/addons/plugin.video.viagenstwt/capas/icon6.png'
icon7 = 'special://home/addons/plugin.video.viagenstwt/capas/icon7.png'
icon8 = 'special://home/addons/plugin.video.viagenstwt/capas/icon8.png'
icon9 = 'special://home/addons/plugin.video.viagenstwt/capas/icon9.png'
icon10 = 'special://home/addons/plugin.video.viagenstwt/capas/icon10.png'
icon11 = 'special://home/addons/plugin.video.viagenstwt/capas/icon11.png'
icon12 = 'special://home/addons/plugin.video.viagenstwt/capas/icon12.png'


def run():
    plugintools.log("viagenstwt.run")
    
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def main_list(params):
		plugintools.log("viagenstwt ===> " + repr(params))

		plugintools.add_item(title = "[B][COLOR white]Viagens e Aventuras Todos Vídeos[/COLOR][/B]" , url = base + "channel/UCgVQqobkMRRMrHQcbT1i5Fg/", thumbnail = icon1, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Férias 2009 nos EUA - Orlando, Miami, New York [/COLOR][/B]" , url = base + "playlist/PLMhJN5GdGqpnog3iCJQAY4BnoOX7g2Vqo/", thumbnail = icon2, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Férias 2010 nos EUA - Califórnia, Las Vegas, Grand Canyon, San Francisco, Big Sur, San Diego[/COLOR][/B]" , url = base + "playlist/PLMhJN5GdGqplahb_QZniUxK2VAmg2yAeD/", thumbnail = icon3, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Férias 2011 na Europa 8 Países e 2 Principados[/COLOR][/B]" , url = base + "PLMhJN5GdGqplHXYN9RpZxPlWJ6nH75zMO/", thumbnail = icon4, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Férias 2012 nos EUA - Orlando[/COLOR][/B]" , url = base + "playlist/PLMhJN5GdGqpnysurumtLimZYDdfwt9zaN/", thumbnail = icon5, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Férias 2014 nos EUA - Califórnia, Las Vegas, Grand Canyon[/COLOR][/B]" , url = base + "playlist/PLMhJN5GdGqplh28w2izyOgipXrqZ9XdNG/", thumbnail = icon6, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Férias 2015 nos EUA - Orlando, Memphis, Atlanta[/COLOR][/B]" , url = base + "playlist/PLMhJN5GdGqplReKPk2GSsnoQVHVlUhR4g/", thumbnail = icon7, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Férias 2016 Trindade - RJ[/COLOR][/B]" , url = base + "playlist/PLMhJN5GdGqplqGO8OlAGxxCKXnIvLUp3V/", thumbnail = icon8, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Férias 2016 nos EUA - Califórnia, Albuquerque, Monument Valley[/COLOR][/B]" , url = base + "playlist/PLMhJN5GdGqpmAwFK4TvJaem92gE0nOLcn/", thumbnail = icon9, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Viagem 2018 nos EUA - Miami - Orlando - NY - SixFlags Great ADdventure[/COLOR][/B]" , url = base + "playlist/PLMhJN5GdGqpkkOyTFSVQaEfGRMT3OTPDM/", thumbnail = icon10, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Six Flags Magic Mountain[/COLOR][/B]" , url = base + "playlist/PLMhJN5GdGqpkWFIgTgkPxu71-5Jhd6ZEo/", thumbnail = icon11, folder = True)
		plugintools.add_item(title = "[B][COLOR white]Beto Carrero 2016[/COLOR][/B]" , url = base + "playlist/PLMhJN5GdGqpn3gY15Nuybo8iF2xeaZKGV/", thumbnail = icon12, folder = True)
	
		
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmc.executebuiltin('Container.SetViewMode(500)')
		
run()