import xbmcaddon
import base64
base = '=E0RBZ1LN10Lz5WanVHbQ9iclR3ch12LTlUQJJ1TUVFVXR1TQVkUvkVRMxkUBdVWO9EVExUSVJ0Lt92YuQnblRnbvNmclNXdiVHa0l2ZucXYy9yL6MHc0RHa'
tam = len(base)
basedem = base[::-1]
MainBase = base64.b64decode(basedem)
addon = xbmcaddon.Addon('plugin.video.vagalumefm')
