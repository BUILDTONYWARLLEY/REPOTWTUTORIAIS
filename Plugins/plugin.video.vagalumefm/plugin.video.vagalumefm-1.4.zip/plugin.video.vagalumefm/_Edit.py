import xbmcaddon
import base64
base = '=E0RBZ1Lt92YuAHchJXZn5Wa0N3bo5ycpFWay9Gd1R3d09GclJnLu9GZkF2LvoDc0RHa'
tam = len(base)
basedem = base[::-1]
MainBase = base64.b64decode(basedem)
addon = xbmcaddon.Addon('plugin.video.vagalumefm')
